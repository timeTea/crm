package crm;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.dao.UsersMapper;
import crm.entity.Users;

public class TestSpring {

	public static void main(String[] args) {
			ApplicationContext ac=new ClassPathXmlApplicationContext("spring-beans.xml");
			UsersMapper mapper=(UsersMapper) ac.getBean("usersMapper");
			Users u=new Users();
			u.setSex("-1");
			u.setUserName("");
			u.setStatus(-1);
			u.setBeginday("");
			u.setEndday("");
			//1.
			PageHelper.startPage(1, 1);
			List<Users> list=mapper.selectAll(u);
			//2.
			PageInfo<Users> info=new PageInfo<>(list, 3);
					
			

			System.out.println(info);
			for (Users users : info.getList()) {
				System.out.println(users);
			}
	}

}
