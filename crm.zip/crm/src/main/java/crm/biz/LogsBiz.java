package crm.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.LogsMapper;
import crm.entity.Bookinfo;
import crm.entity.Logs;

@Service
public class LogsBiz {
	
	@Autowired
	LogsMapper logsMapper;
	
	public int addlogs(Logs log){
		return logsMapper.insert(log);
	}
	
	public List<Logs> getLogs(Logs log){
		return logsMapper.selectAll(log);
	}
	
	public int deleteLogs(int logId){
		return logsMapper.deleteByPrimaryKey(logId);
	}

}
