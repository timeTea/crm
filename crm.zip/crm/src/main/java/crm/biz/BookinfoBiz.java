package crm.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.BookinfoMapper;
import crm.entity.Bookinfo;

@Service
public class BookinfoBiz {
	
	@Autowired
	BookinfoMapper bookinfoMapper;
	
	public int addbookinfo(Bookinfo bookinfo){
		return bookinfoMapper.insert(bookinfo);
	}
	
	public List<Bookinfo> getBookinfo(Bookinfo bookinfo){
		return bookinfoMapper.selectAll(bookinfo);
	}
	
	public int deleteBookinfor(int bookId){
		return bookinfoMapper.deleteByPrimaryKey(bookId);
	}
	
}
