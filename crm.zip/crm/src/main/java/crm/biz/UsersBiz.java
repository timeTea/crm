package crm.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.UsersMapper;
import crm.entity.Users;

@Service
public class UsersBiz {
	@Autowired
	UsersMapper  usersMapper;
	
	public Users login(String name,String password){
		return usersMapper.login(name, password);
	}
	
	public int adduser(Users users){
		return usersMapper.insert(users);
	}
	
	public List<Users> getUsers(Users users){
		return usersMapper.selectAll(users);
	}
	
	public Users getUserId(String name){
		return usersMapper.getUserId(name);
	}
	public int deleteuser(int userId){
		return usersMapper.deleteByPrimaryKey(userId);
	}
	
	public int updateUser(int userId,int roleId){
		return usersMapper.editRole(roleId, userId);
	}
	public List<Users> getuser(Users users){
		return usersMapper.getuserId();
	}
}
