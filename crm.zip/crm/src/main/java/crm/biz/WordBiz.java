package crm.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.CustomersMapper;
import crm.dao.WordsMapper;
import crm.entity.Words;

@Service
public class WordBiz {
	@Autowired
	WordsMapper  wordsMapper;
	
	@Autowired
	CustomersMapper  customersMapper;

	public int addWords(Words words){
		return wordsMapper.insert(words);
	}
	
	public List<Words> getWords(Words words){
		return wordsMapper.selectAll(words);
	}
	
	public int deleteWord(int wordId){
		return wordsMapper.deleteByPrimaryKey(wordId);
	}
	

	
}

