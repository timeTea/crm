package crm.biz;

import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.ContactsMapper;

import crm.entity.Contacts;

@Service
public class ConBiz {
	@Autowired
	ContactsMapper  conMapper;
	
	
	
	public int addcon(Contacts con){
		return conMapper.insert(con);
	}
	public int deletecon(Integer  con){
		return conMapper.deleteByPrimaryKey(con);
	}
	public List<Contacts> getcon(Contacts con){
		return conMapper.selectAll(con);
	}
	

	
}
