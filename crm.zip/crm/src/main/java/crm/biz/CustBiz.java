package crm.biz;

import java.io.IOException;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import crm.dao.ContactsMapper;
import crm.dao.CustomersMapper;
import crm.entity.Customers;

@Service
public class CustBiz {
	@Autowired
	CustomersMapper  custMapper;
	@Autowired
	ContactsMapper  conMapper;
	
	
	
	public int addcust(Customers cust){
		return custMapper.insert(cust);
	}
	public int deleteCust(int custId){
			 conMapper.deleteByCustKey(custId);
		return custMapper.deleteByPrimaryKey(custId);
	}
	public List<Customers> getResult(Customers cust){
		return custMapper.selectResult(cust);
	}
	public List<Customers> getcust(Customers cust){
		return custMapper.selectAll(cust);
	}
	public int updateCust(int userId,String roleId){
		return custMapper.editCust(userId, roleId);
	}

	
}
