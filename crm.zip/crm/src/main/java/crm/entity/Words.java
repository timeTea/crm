package crm.entity;

import java.io.Serializable;
import java.util.Date;

public class Words implements Serializable {
    private Integer wordId;

    private String title;


	private String summary;

    private Integer custId;

    private Integer userId;

    private String time;
    
    private Date createTime;
    
    private String type;
    
    private Customers cust;
    
    private Users user;
    
    public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	private String custName;
    	

    public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Customers getCust() {
		return cust;
	}

	public void setCust(Customers cust) {
		this.cust = cust;
	}

	public Words() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Words(Integer wordId, String title, String summary, Integer custId, Integer userId, String time,
			Date createTime, String type, String beginday, String endday) {
		super();
		this.wordId = wordId;
		this.title = title;
		this.summary = summary;
		this.custId = custId;
		this.userId = userId;
		this.createTime = createTime;
		this.type = type;

	}

	@Override
	public String toString() {
		return "Words [wordId=" + wordId + ", title=" + title + ", summary=" + summary + ", custId=" + custId
				+ ", userId=" + userId + ", createTime=" + createTime +  ", time=" + time +", type=" + type
				+ "]";
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	private String beginday;
    private String endday;
    
    public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getBeginday() {
		return beginday;
	}

	public void setBeginday(String beginday) {
		this.beginday = beginday;
	}

	public String getEndday() {
		return endday;
	}

	public void setEndday(String endday) {
		this.endday = endday;
	}

    public Integer getWordId() {
        return wordId;
    }

    public void setWordId(Integer wordId) {
        this.wordId = wordId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary == null ? null : summary.trim();
    }

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    
}