package crm.entity;

import java.util.Date;

public class Bookinfo {
	 private Integer bookId;

	    private Integer title;

	    private String des;

	    private Date bookTime;

	    private Date createTime;
	    
	    private String bTime;
	    
	    private String cTime;

	    private Customers customer;
	    
		private String beginday;
	    private String endday;

	    
	    
		public String getBeginday() {
			return beginday;
		}

		public void setBeginday(String beginday) {
			this.beginday = beginday;
		}

		public String getEndday() {
			return endday;
		}

		public void setEndday(String endday) {
			this.endday = endday;
		}

		public Customers getCustomer() {
			return customer;
		}

		public void setCustomer(Customers customer) {
			this.customer = customer;
		}

		public String getbTime() {
			return bTime;
		}

		public void setbTime(String bTime) {
			this.bTime = bTime;
		}

		public String getcTime() {
			return cTime;
		}

		public void setcTime(String cTime) {
			this.cTime = cTime;
		}

		public Integer getBookId() {
	        return bookId;
	    }

	    public void setBookId(Integer bookId) {
	        this.bookId = bookId;
	    }

	    public Integer getTitle() {
	        return title;
	    }

	    public void setTitle(Integer title) {
	        this.title = title;
	    }

	    public String getDes() {
			return des;
		}

		public void setDes(String des) {
			this.des = des;
		}

		public Date getBookTime() {
	        return bookTime;
	    }

	    public void setBookTime(Date bookTime) {
	        this.bookTime = bookTime;
	    }

	    public Date getCreateTime() {
	        return createTime;
	    }

	    public void setCreateTime(Date createTime) {
	        this.createTime = createTime;
	    }

	}