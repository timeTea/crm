package crm.entity;
import java.io.Serializable;
import java.util.Date;

public class Customers implements Serializable{
    private Integer customerId;
    private String userName;
    private String custName;

    private Integer custType;

    private Integer custBackground;

    private String listed;

    private Integer regCapital;

    private Integer yearSales;

    private Integer entpScale;

    private Integer testerNo;

    private String url;

    private String zipCode;

    private String address;

    private String mainProducts;

    private String majorServices;

    private String status;

    private Integer userId;

    private Date createTime;
    private String time;
    private	Contacts contact;
    private Users user;
   
	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Contacts getContact() {
		return contact;
	}

	public void setContact(Contacts contact) {
		this.contact = contact;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Customers() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName == null ? null : custName.trim();
    }

    public Integer getCustType() {
        return custType;
    }

    public void setCustType(Integer custType) {
        this.custType = custType;
    }

    public Integer getCustBackground() {
        return custBackground;
    }

    public void setCustBackground(Integer custBackground) {
        this.custBackground = custBackground;
    }

    public String getListed() {
        return listed;
    }

    public void setListed(String listed) {
        this.listed = listed == null ? null : listed.trim();
    }

    public Integer getRegCapital() {
        return regCapital;
    }

    public void setRegCapital(Integer regCapital) {
        this.regCapital = regCapital;
    }

    public Integer getYearSales() {
        return yearSales;
    }

    public void setYearSales(Integer yearSales) {
        this.yearSales = yearSales;
    }

    public Integer getEntpScale() {
        return entpScale;
    }

    public void setEntpScale(Integer entpScale) {
        this.entpScale = entpScale;
    }

    public Integer getTesterNo() {
        return testerNo;
    }

    public void setTesterNo(Integer testerNo) {
        this.testerNo = testerNo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode == null ? null : zipCode.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getMainProducts() {
        return mainProducts;
    }

    public void setMainProducts(String mainProducts) {
        this.mainProducts = mainProducts == null ? null : mainProducts.trim();
    }

    public String getMajorServices() {
        return majorServices;
    }

    public void setMajorServices(String majorServices) {
        this.majorServices = majorServices == null ? null : majorServices.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    @Override
	public String toString() {
		return "customers [customerId=" + customerId + ", custName=" + custName + ", custType=" + custType + ", custBackground=" + custBackground
				+ ", listed=" + listed + ",regCapital=" + regCapital + ", yearSales=" + yearSales+ ", entpScale=" + entpScale
				+ ", testerNo=" + testerNo+",url="+url+",zipCode="+zipCode+",address="+address+",mainProducts="+mainProducts+",majorServices="+majorServices + ", status=" + status+", userId=" +userId +", createTime=" +createTime + "]";
	}

	public Customers(Integer customerId, String custName, Integer custType, Integer custBackground, String listed,
			Integer regCapital, Integer yearSales, Integer entpScale, Integer testerNo, String url, String zipCode,
			String address, String mainProducts, String majorServices, String status, Integer userId, Date createTime) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.custType = custType;
		this.custBackground = custBackground;
		this.listed = listed;
		this.regCapital = regCapital;
		this.yearSales = yearSales;
		this.entpScale = entpScale;
		this.testerNo = testerNo;
		this.url = url;
		this.zipCode = zipCode;
		this.address = address;
		this.mainProducts = mainProducts;
		this.majorServices = majorServices;
		this.status = status;
		this.userId = userId;
		this.createTime = createTime;
	}
    
    
}
