package crm.entity;

import java.io.Serializable;
import java.util.Date;

public class Users implements Serializable {
    private Integer userId;

    private String userName;

    private String password;

    private String sex;

    private String time;
    
    public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	
	private String beginday;
    private Date birthday;
    private String endday;
    
    

	public String getBeginday() {
		return beginday;
	}

	public void setBeginday(String beginday) {
		this.beginday = beginday;
	}

	public String getEndday() {
		return endday;
	}

	public void setEndday(String endday) {
		this.endday = endday;
	}


	private	 Roles  role;
	
	//private Integer roleId;
	private	 Customers customer;
   

	public Roles getRole() {
		return role;
	}

	@Override
	public String toString() {
		return "Users [userId=" + userId + ", userName=" + userName + ", password=" + password + ", sex=" + sex
				+ ", time=" + time + ", beginday=" + beginday + ", birthday=" + birthday + ", endday=" + endday
				+ ", role=" + role + ", status=" + status + "]";
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	private Integer status=1;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

//    public Integer getRoleId() {
//        return roleId;
//    }
//
//    public void setRoleId(Integer roleId) {
//        this.roleId = roleId;
//    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

//	@Override
//	public String toString() {
//		return "Users [userId=" + userId + ", userName=" + userName + ", password=" + password + ", sex=" + sex
//				+ ", birthday=" + birthday + ", roleId=" + roleId + ", status=" + status + "]";
//	}

	public Users(String userName, String password, String sex, Date birthday, Integer roleId, Integer status) {
		super();
		this.userName = userName;
		this.password = password;
		this.sex = sex;
		this.birthday = birthday;
		//this.roleId = roleId;
		this.status = status;
	}

	public Users() {
		super();
	}

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
    
}