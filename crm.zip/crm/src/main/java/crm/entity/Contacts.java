package crm.entity;

import java.util.Date;

public class Contacts {
    private Integer contId;

    private Integer custId;

    private String contName;

    private String contDept;

    private String contPosition;

    private String contTelephone;

    private String contMobile;

    private String contEmail;

    private String contQq;

    private String techDegree;

    private String moreInfo;

    private Customers customer;
    private String custName;
    public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}
    private Date createTime;
	private String beginday;
    public String getBeginday() {
		return beginday;
	}

	public void setBeginday(String beginday) {
		this.beginday = beginday;
	}

	public String getEndday() {
		return endday;
	}

	public void setEndday(String endday) {
		this.endday = endday;
	}

	private String endday;
    private String time;
    
    public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

    public Integer getContId() {
        return contId;
    }

    public void setContId(Integer contId) {
        this.contId = contId;
    }

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public String getContName() {
        return contName;
    }

    public void setContName(String contName) {
        this.contName = contName == null ? null : contName.trim();
    }

    public String getContDept() {
        return contDept;
    }

    public void setContDept(String contDept) {
        this.contDept = contDept == null ? null : contDept.trim();
    }

    public String getContPosition() {
        return contPosition;
    }

    public void setContPosition(String contPosition) {
        this.contPosition = contPosition == null ? null : contPosition.trim();
    }

    public String getContTelephone() {
        return contTelephone;
    }

    public void setContTelephone(String contTelephone) {
        this.contTelephone = contTelephone == null ? null : contTelephone.trim();
    }

    public String getContMobile() {
        return contMobile;
    }

    public void setContMobile(String contMobile) {
        this.contMobile = contMobile == null ? null : contMobile.trim();
    }

    public String getContEmail() {
        return contEmail;
    }

    public void setContEmail(String contEmail) {
        this.contEmail = contEmail == null ? null : contEmail.trim();
    }

    public String getContQq() {
        return contQq;
    }

    public void setContQq(String contQq) {
        this.contQq = contQq == null ? null : contQq.trim();
    }

    public String getTechDegree() {
        return techDegree;
    }

    public void setTechDegree(String techDegree) {
        this.techDegree = techDegree == null ? null : techDegree.trim();
    }

    public String getMoreInfo() {
        return moreInfo;
    }

    public void setMoreInfo(String moreInfo) {
        this.moreInfo = moreInfo == null ? null : moreInfo.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

	public Customers getCustomer() {
		return customer;
	}

	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
}