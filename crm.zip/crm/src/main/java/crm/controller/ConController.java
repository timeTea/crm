package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.biz.ConBiz;
import crm.biz.CustBiz;
import crm.biz.UsersBiz;
import crm.entity.Contacts;
import crm.entity.Roles;
import crm.entity.Users;
import crm.entity.Customers;

//https://www.jquery123.com/

@Controller
public class ConController {
	
	/*@RequestMapping(value="testSprimgmvc",method=RequestMethod.GET,params={"num"})
	public ModelAndView testSprimgmvc(@RequestParam int num){
		
		 * /WEB-INF/views/hello.jsp
		
		System.out.println("num:"+num);
		ModelAndView  mv=new ModelAndView("hello");
		mv.addObject("name", "modelandview");
		return mv;
	}
	
	//pojo
	@RequestMapping("testPojo")
	@ResponseBody
	public Object testPojo(Users user){
	
		return user;
	}
	 */

	
	@RequestMapping("addContacts")
	public String addContacts(){
		return "addContacts";
	}
	
	
	
	@RequestMapping("contactsList")
	public String contactsList(){
		return "contactsList";
	}
	
	@Autowired
	ConBiz conBiz;
	@RequestMapping("formAddCon")
	@ResponseBody
	public String insertCust(Contacts con){
		try {
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(con.getTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(con.getTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(con.getTime().split("-")[2]));
			System.out.println(c);
			con.setCreateTime(new Date(c.getTimeInMillis()));
			System.out.println("??????????"+con);
			//2018-09-30--->date
			int row = conBiz.addcon(con);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
	@RequestMapping("getConData")
	@ResponseBody
	public Object getConData(Contacts con,@RequestParam String pageNum,@RequestParam String pageSize){
		con.setCustName("%"+con.getCustName()+"%");
		System.out.println(con);
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Contacts> list=conBiz.getcon(con);
		PageInfo<Contacts> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	@RequestMapping("deleteCon")
	@ResponseBody
	public String deleteCust(String conId){
		System.out.println(Integer.parseInt(conId));
		int row=conBiz.deletecon(Integer.parseInt(conId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
}

	


	
	

