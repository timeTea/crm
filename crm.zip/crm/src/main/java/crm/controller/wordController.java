package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;


import crm.biz.WordBiz;
import crm.biz.CustBiz;
import crm.entity.Users;
import crm.entity.Words;

//https://www.jquery123.com/

@Controller
public class wordController {
	
	@Autowired
	WordBiz wordBiz;
	
	@Autowired
	CustBiz customersBiz;
	

	@RequestMapping("wordList")
	public String wordList(){
		return "wordList";
	}
	@RequestMapping("addWord")
	public String addWord(){
		return "addWord";
	}
	
	//�����ĵ�
	@RequestMapping("formAddWord")
	@ResponseBody
	public String insertWord(Words Word){
		try {
			System.out.println(Word);
			//2018-09-30--->date
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(Word.getTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(Word.getTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(Word.getTime().split("-")[2]));
			System.out.println(c);
			Word.setCreateTime(new Date(c.getTimeInMillis()));
			int row = wordBiz.addWords(Word);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	@RequestMapping("getWordData")
	@ResponseBody
	public Object getWordData(Words words,@RequestParam String pageNum,@RequestParam String pageSize){
		words.setTitle("%"+words.getTitle()+"%");
		System.out.println(words.getTitle());
		words.setCustName("%"+words.getCustName()+"%");
		System.out.println(words.getCustName());
		
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Words> list=wordBiz.getWords(words);
		PageInfo<Words> info=new PageInfo<>(list, 3);
		
		return info;
	}
	@RequestMapping("deleteWord")
	@ResponseBody
	public String deleteUser(int wordId){
		int row=wordBiz.deleteWord(wordId);
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
}
