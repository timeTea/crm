package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.biz.LogsBiz;
import crm.entity.Bookinfo;
import crm.entity.Users;
import crm.entity.Customers;
import crm.entity.Logs;

@Controller
public class LogsController {
	
	@Autowired
	LogsBiz logsBiz;
	
	@RequestMapping("addLog")
	public String addLog(){
		return "addLog";
	}
	
	@RequestMapping("logList")
	public String logList(){
		return "logList";
	}
	
	@RequestMapping("deleteLog")
	@ResponseBody
	public String deleteLogs(String logId){
		int row=logsBiz.deleteLogs(Integer.parseInt(logId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
	@RequestMapping("getLogData")
	@ResponseBody
	public Object getData(Logs log,@RequestParam String pageNum,@RequestParam String pageSize){

		Customers cu=log.getCustomer();
		cu.setCustName("%"+log.getCustomer().getCustName()+"%");
		
		log.setCustomer(cu);
		System.out.println("???");
		System.out.println(log.getCustomer().getCustName());
		System.out.println("???");
		
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Logs> list=logsBiz.getLogs(log);
		PageInfo<Logs> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	//��������
	@RequestMapping("formAddLog")
	@ResponseBody
	public String insertLog(Logs log){
		try {
			//2018-09-30--->date
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(log.getcTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(log.getcTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(log.getcTime().split("-")[2]));
			log.setCreateTime(new Date(c.getTimeInMillis()));
			int row = logsBiz.addlogs(log);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
}
