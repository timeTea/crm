package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.biz.BookinfoBiz;
import crm.entity.Bookinfo;
import crm.entity.Users;
import crm.entity.Customers;

@Controller
public class BookinfoController {
	
	@Autowired
	BookinfoBiz bookinfoBiz;
	
	@RequestMapping("addBookinfo")
	public String addBookinfo(){
		return "addBookinfo";
	}
	@RequestMapping("bookinfoList")
	public String bookinfoList(){
		return "bookinfoList";
	}
	
	@RequestMapping("deleteBookinfo")
	@ResponseBody
	public String updateUser(String bookId){
		int row=bookinfoBiz.deleteBookinfor(Integer.parseInt(bookId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
	@RequestMapping("getBookinfoData")
	@ResponseBody
	public Object getData(Bookinfo bookinfo,@RequestParam String pageNum,@RequestParam String pageSize){
		
		System.out.println("qiujinhuaiwudi");
		Customers cu=bookinfo.getCustomer();
		cu.setCustName("%"+bookinfo.getCustomer().getCustName()+"%");
		
		bookinfo.setCustomer(cu);
		System.out.println("?????");
		System.out.println(bookinfo.getCustomer().getCustName());
		System.out.println("?????");
		
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Bookinfo> list=bookinfoBiz.getBookinfo(bookinfo);
		System.out.println("?????");
		System.out.println(list.toString());
		System.out.println("?????");
		PageInfo<Bookinfo> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	
	//��������
	@RequestMapping("formAddBookinfo")
	@ResponseBody
	public String insertBookinfo(Bookinfo bookinfo){
		try {
			//2018-09-30--->date
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(bookinfo.getbTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(bookinfo.getbTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(bookinfo.getbTime().split("-")[2]));
			bookinfo.setBookTime(new Date(c.getTimeInMillis()));
			Calendar d=Calendar.getInstance();
			d.set(Calendar.YEAR,Integer.parseInt(bookinfo.getcTime().split("-")[0]));
			d.set(Calendar.MONTH, Integer.parseInt(bookinfo.getcTime().split("-")[1]));
			d.set(Calendar.DAY_OF_YEAR, Integer.parseInt(bookinfo.getcTime().split("-")[2]));
			bookinfo.setCreateTime(new Date(d.getTimeInMillis()));
			int row = bookinfoBiz.addbookinfo(bookinfo);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}
