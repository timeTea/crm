package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.biz.UsersBiz;
import crm.entity.Roles;
import crm.entity.Users;

//https://www.jquery123.com/

@Controller
public class UserController {
	
	/*@RequestMapping(value="testSprimgmvc",method=RequestMethod.GET,params={"num"})
	public ModelAndView testSprimgmvc(@RequestParam int num){
		
		 * /WEB-INF/views/hello.jsp
		
		System.out.println("num:"+num);
		ModelAndView  mv=new ModelAndView("hello");
		mv.addObject("name", "modelandview");
		return mv;
	}
	
	//pojo
	@RequestMapping("testPojo")
	@ResponseBody
	public Object testPojo(Users user){
	
		return user;
	}
	 */
	@Autowired
	UsersBiz usersBiz;
	
	@RequestMapping("/")
	public String home(){
		return "login";
	}
	
	@RequestMapping("login")
	public ModelAndView  login(@RequestParam String name,@RequestParam String password,HttpServletRequest request){
		Users user= usersBiz.login(name, password);
		ModelAndView m=null;
		if(user!=null){
			m=new ModelAndView("index");
			m.addObject("user",user);
			HttpSession session = request.getSession();
			session.setAttribute("username", name);

		}else{
			m=new ModelAndView("login");
			m.addObject("error", "�û������������");
		}
		return m;
	}

	
	
	@RequestMapping("addUser")
	public String addUser(){
		return "addUser";
	}
	
	
	
	@RequestMapping("userList")
	public String userList(){
		return "userList";
	}



	
	
	@RequestMapping("getData")
	@ResponseBody
	public Object getData(Users users,@RequestParam String pageNum,@RequestParam String pageSize){
		users.setUserName("%"+users.getUserName()+"%");
		System.out.println(users);
		
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Users> list=usersBiz.getUsers(users);
		PageInfo<Users> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	//�����û�
	@RequestMapping("formAddUser")
	@ResponseBody
	public String insertUser(Users user){
		try {
			System.out.println(user);
			//2018-09-30--->date
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(user.getTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(user.getTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(user.getTime().split("-")[2]));
			System.out.println(c);
			user.setBirthday(new Date(c.getTimeInMillis()));
			int row = usersBiz.adduser(user);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
	
	@RequestMapping("deleteUser")
	@ResponseBody
	public String deleteUser(String userId){
		int row=usersBiz.deleteuser(Integer.parseInt(userId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
	@RequestMapping("updateUser")
	@ResponseBody
	public String updateUser(String userId,String roleId){
		int row=usersBiz.updateUser(Integer.parseInt(userId), Integer.parseInt(roleId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
	
	@RequestMapping("getuserId")
	@ResponseBody
	public Object getcust(Users users){

		List<Users> list=usersBiz.getuser(users);
		
		return list;
	}
	
}
