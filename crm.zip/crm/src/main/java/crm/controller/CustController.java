package crm.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import crm.biz.CustBiz;
import crm.biz.UsersBiz;
import crm.entity.Roles;
import crm.entity.Users;
import crm.entity.Customers;

//https://www.jquery123.com/

@Controller
public class CustController {
	@RequestMapping(value="testSprimgmvc",method=RequestMethod.GET,params={"num"})
	public ModelAndView testSprimgmvc(@RequestParam int num){
		
		
		
		System.out.println("num:"+num);
		ModelAndView  mv=new ModelAndView("hello");
		mv.addObject("name", "modelandview");
		return mv;
	}
	
	
	/*@RequestMapping(value="testSprimgmvc",method=RequestMethod.GET,params={"num"})
	public ModelAndView testSprimgmvc(@RequestParam int num){
	
	
		 
		System.out.println("num:"+num);
		ModelAndView  mv=new ModelAndView("hello");
		mv.addObject("name", "modelandview");
		return mv;
	}
	
	pojo
	@RequestMapping("testPojo")
	@ResponseBody
	public Object testPojo(Users user){
	
		return user;
	}
	
	@Autowired
	UsersBiz usersBiz;
	
	@RequestMapping("/")
	public String home(){
		return "login";
	}
	
	@RequestMapping("login")
	public ModelAndView  login(@RequestParam String name,@RequestParam String password){
		Users user= usersBiz.login(name, password);
		ModelAndView m=null;
		if(user!=null){
			m=new ModelAndView("index");
			m.addObject("user",user);
		}else{
			m=new ModelAndView("login");
			m.addObject("error", "�û������������");
		}
		return m;
	}
	
	@RequestMapping("addUser")
	public String addUser(){
		return "addUser";
	}
	
	
	
	@RequestMapping("userList")
	public String userList(){
		return "userList";
	}

	@RequestMapping("addCust")
	public String addCust(){
		return "addCust";
	}
	@RequestMapping("custList")
	public String custList(){
		return "custList";
	}
	@RequestMapping("addLog")
	public String addLog(){
		return "addLog";
	}
	@RequestMapping("logList")
	public String logList(){
		return "logList";
	}
	
	
	@RequestMapping("getData")
	@ResponseBody
	public Object getData(Users users,@RequestParam String pageNum,@RequestParam String pageSize){
		users.setUserName("%"+users.getUserName()+"%");
		System.out.println(users);
		
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Users> list=usersBiz.getUsers(users);
		PageInfo<Users> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	//�����û�
	@RequestMapping("formAddUser")
	@ResponseBody
	public String insertUser(Users user){
		try {
			System.out.println(user);
			//2018-09-30--->date
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(user.getTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(user.getTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(user.getTime().split("-")[2]));
			System.out.println(c);
			user.setBirthday(new Date(c.getTimeInMillis()));
			int row = usersBiz.adduser(user);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
	
	@RequestMapping("deleteUser")
	@ResponseBody
	public String deleteUser(String userId){
		int row=usersBiz.deleteuser(Integer.parseInt(userId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	
	@RequestMapping("updateUser")
	@ResponseBody
	public String updateUser(String userId,String roleId){
		int row=usersBiz.updateUser(Integer.parseInt(userId), Integer.parseInt(roleId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	@RequestMapping("addCust")
	public String addCust(){
		System.out.println("addCust");
		return "addCust";
	}
	@RequestMapping("custList")
	public String custList(){
		return "custList";
	}
	@RequestMapping("formAddCust")
	@ResponseBody
	public String insertCust(customers cust){
		try {
			System.out.println(cust);
			//2018-09-30--->date
			//Calendar c=Calendar.getInstance();
			//c.set(Calendar.YEAR, Integer.parseInt(cust.getCreateTime().split("-")[0]));
			//c.set(Calendar.MONTH, Integer.parseInt(cust.getCreateTime().split("-")[1]));
			//c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(cust.getCreateTime().split("-")[2]));
			//System.out.println(c);
			return "success";
		} catch (Exception e) {
			return e.getMessage();
		}
	}*/
	@RequestMapping("testPojo")
	@ResponseBody
	public Object testPojo(Users user){
	
		return user;
	}
	@Autowired
	CustBiz custBiz;
	@Autowired
	UsersBiz usersBiz;
	@RequestMapping("addCust")
	public String addCust(){
		System.out.println("addCust");
		return "addCust";
	}
	@RequestMapping("custList")
	public String custList(){
		return "custList";
	}
	

	@RequestMapping("getCustData")
	@ResponseBody
	public Object getCustData(Customers cust,@RequestParam String pageNum,@RequestParam String pageSize){
		cust.setCustName("%"+cust.getCustName()+"%");
		System.out.println(cust);
		PageHelper.startPage(Integer.parseInt(pageNum), Integer.parseInt(pageSize));
		List<Customers> list=custBiz.getResult(cust);
		PageInfo<Customers> info=new PageInfo<>(list, 3);
		
		return info;
	}
	
	
	@RequestMapping("GetUserId")
	@ResponseBody
	public Object getUserId(Customers cust){
		System.out.println("???"+cust.getUserId()+cust);
		List<Customers> list=custBiz.getcust(cust);
	
		
		return list;
	}
	
	@RequestMapping("formAddCust")
	@ResponseBody
	public String insertCust(Customers cust){
		try {
			Calendar c=Calendar.getInstance();
			c.set(Calendar.YEAR, Integer.parseInt(cust.getTime().split("-")[0]));
			c.set(Calendar.MONTH, Integer.parseInt(cust.getTime().split("-")[1]));
			c.set(Calendar.DAY_OF_YEAR, Integer.parseInt(cust.getTime().split("-")[2]));
			System.out.println(c);
			cust.setCreateTime(new Date(c.getTimeInMillis()));
			cust.setUserId(usersBiz.getUserId(cust.getUserName()).getUserId());
			System.out.println("??????????"+cust);
			//2018-09-30--->date
			int row = custBiz.addcust(cust);
			if (row > 0) {
				return "true";
			} else {
				return "add fail";
			} 
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	@RequestMapping("deleteCust")
	@ResponseBody
	public String deleteCust(String custId){
		System.out.println(Integer.parseInt(custId));
		int row=custBiz.deleteCust(Integer.parseInt(custId));
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
	@RequestMapping("updateCust")
	@ResponseBody
	public String updateCust(String custId,String status){
		System.out.println("update11"+custId+status);
		int row=custBiz.updateCust(Integer.parseInt(custId), status);
		if(row>0){
			return "true";
		}else{
			return "false";
		}
		
	}
}
