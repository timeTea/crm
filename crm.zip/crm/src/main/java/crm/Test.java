package crm;

import java.io.InputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import crm.dao.UsersMapper;
import crm.entity.Users;


public class Test {

	public static void main(String[] args) {
		try {
			String resource = "mybatis-config.xml";
			InputStream inputStream = Resources.getResourceAsStream(resource);
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			SqlSession session = sqlSessionFactory.openSession();
			System.out.println(session);
			UsersMapper mapper=session.getMapper(UsersMapper.class);
			//Users users=mapper.selectByPrimaryKey(1);
			//System.out.println(users);
			
			//����û���
			//Users u=mapper.checkName("testMybatis------");
			//System.out.println(u);
			
			//�����û�		
			//Users u=new Users( "testadd", "1234", "Ů", new Date(System.currentTimeMillis()),
			//		3, 0);
			//int rows=mapper.insert(u);
			
			//ɾ���û�
		//	int rows=mapper.deleteByID(3);
		//	System.out.println("rows:"+rows);
			
			
			
			
			//��¼
		//	Users u= mapper.login("test", "123456");
		//	System.out.println(u);
			
			
			//�����ɫ
		//	int rows=mapper.editRole(2, 5);
		//	System.out.println("rows:"+rows);
		
			//������ѯ
			Users u=new Users();
			//u.setUserName("%a%");
			//u.setSex("��");
			//u.setRoleId(3);
			//u.setBeginday(new java.util.Date(new java.util.Date(90, 0, 1).getTime()));
			//u.setEndday(new java.util.Date(new java.util.Date(100, 0, 1).getTime()));
			List<Users> list=mapper.selectAll(u);
			for (Users users : list) {
				System.out.println(users);
			}
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
