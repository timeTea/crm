package crm.dao;

import crm.entity.Bookinfo;
import java.util.List;

public interface BookinfoMapper {
    int deleteByPrimaryKey(Integer bookId);

    int insert(Bookinfo record);

    Bookinfo selectByPrimaryKey(Integer bookId);

    List<Bookinfo> selectAll(Bookinfo b);

    int updateByPrimaryKey(Bookinfo record);
}