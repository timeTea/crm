package crm.dao;

import crm.entity.Customers;
import crm.entity.Users;

import java.util.List;

public interface CustomersMapper {
    int deleteByPrimaryKey(Integer customerId);

    int insert(Customers record);

    Customers selectByPrimaryKey(Integer customerId);

    List<Customers> selectAll(Customers u);
    List<Customers> selectResult(Customers u);


    int updateByPrimaryKey(Customers record);
    int editCust(int cust_id,String user_id);
}