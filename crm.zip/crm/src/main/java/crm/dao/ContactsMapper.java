package crm.dao;

import crm.entity.Contacts;
import java.util.List;

public interface ContactsMapper {
    int deleteByPrimaryKey(Integer contId);
    int deleteByCustKey(Integer custId);
    int insert(Contacts record);

    Contacts selectByPrimaryKey(Integer contId);

    List<Contacts> selectAll(Contacts con);

    int updateByPrimaryKey(Contacts record);
}