package crm.dao;

import crm.entity.Users;
import java.util.List;

public interface UsersMapper {
    int deleteByPrimaryKey(Integer userId);

    int insert(Users record);

    Users selectByPrimaryKey(Integer userId);

    List<Users> selectAll(Users u);

    int updateByPrimaryKey(Users record);
    
    Users login(String name,String password);
    
    Users checkName(String name);
    
    Users getUserId(String name);
    int editRole(int role_id,int user_id);
    List<Users> getuserId();
}