package crm.dao;

import crm.entity.Logs;
import java.util.List;

public interface LogsMapper {
    int deleteByPrimaryKey(Integer logId);

    int insert(Logs record);

    Logs selectByPrimaryKey(Integer logId);

    List<Logs> selectAll(Logs b);

    int updateByPrimaryKey(Logs record);
}