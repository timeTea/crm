package crm.dao;

import crm.entity.Words;
import java.util.List;

public interface WordsMapper {
    int deleteByPrimaryKey(Integer wordId);

    int insert(Words record);

    Words selectByPrimaryKey(Integer wordId);

    List<Words> selectAll(Words u);

    int updateByPrimaryKey(Words record);
}